create function st_forcepolygonccw(geometry) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$ SELECT public.ST_Reverse(public.ST_ForcePolygonCW($1)) $$;

alter function st_forcepolygonccw(geometry) owner to postgres;

